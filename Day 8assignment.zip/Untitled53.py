#!/usr/bin/env python
# coding: utf-8

# In[2]:



get_ipython().run_cell_magic('writefile', 'test.txt', '\nHi this is sankalp\ni love letsupgrade')


# In[3]:


try:
    
    file = open("test.txt","r")
    
    file.write("\nI am from chennai.")
    
    print("\nWrite operation has done successfully in read only mode.")
    
except Exception as e:
    
    print("\nError has been occured")
    
    print("\nError message is :",e)


# In[ ]:





# In[ ]:




